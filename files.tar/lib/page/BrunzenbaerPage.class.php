<?php
namespace wcf\page;

/**
 * Shows the Brunzenbaer page.
 * 
 * @author	Oliver Schlöbe
 * @copyright 2014 schloebe.de
 * @license	LGPL
 * @package	de.schloebe.wbb.brunzenbaer
 */
class BrunzenbaerPage extends AbstractPage { }